<?php
    include 'functions.php';
	
    writeHead("Required Compitency 2A");
    
                
                    
                        echo $_GET['AlbumnID']. " ".$_GET['AlbumnName']." by ".$_GET['ArtistName']." added";
                   writeFoot();
				    ?>
                
          

             
        