﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace customerCombobox
{
    public partial class Form1 : Form
    {
        string conString = @"Data Source=DESKTOP-70QDRLQ\SQLEXPRESS;Initial Catalog=TechSupport;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
            FillCombo();
        }
        void FillCombo()
        {

            string query = "select * from TechSupport.Customers ";
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader;
            try
            {
                con.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string name = reader.GetString(Name);
                    cbo1.Items.Add(name);

                }
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.Message);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cbo1_SelectedIndexChanged(object sender, EventArgs e)
        {
            IEnumerable<Customers> query = from customersCopy in Customers where customersCopy.CustomerID= 
                                           Customers.CustomerID select customersCopy;
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader;
            try
            {
                con.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    tbxCustomerID = reader.GetString("CustomerID").ToString();
                    tbxName = reader.GetString("Name");
                    tbxAddress = reader.GetString("Address");
                    tbxCity = reader.GetString("City");
                    tbxState = reader.GetString("State");
                    tbxZipCode = reader.GetString("ZipCode");
                    tbxPhone = reader.GetString("Phone");
                    tbxEmail = reader.GetString("Email");


                }
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            /* string conString = @"Data Source=DESKTOP-70QDRLQ\SQLEXPRESS;Initial Catalog=TechSupport;Integrated Security=True";
             string query = Update TechSupport.Customers set(Name, Address, City, State, ZipCode, Phone, Email ) (Name='" +this.tbxName.text'",Address='" + this.tbxAddress.text'",
                 City = '" +this.tbxCity.text'",State='" + this.tbxState.text'",ZipCode='" +this.tbxZipCode.text'",Phone = '" +this.tbxPhone.text'",Email='" + this.tbxEmail.Text'");";
             SqlConnection con = new SqlConnection(conString);
             SqlCommand cmd = new SqlCommand(query, con);
             SqlDataReader reader;
             try
             {
                 con.Open();
                 reader = cmd.ExecuteReader();
                 while (reader.Read())
                 {
                     string name = reader.GetString("Name");
                     cbo1.Items.Add(name);

                 }
             }
             catch (Exception exe)
             {
                 MessageBox.Show(exe.Message);
             }
         }*/
            if (tbxName.Text != "" || tbxAddress.Text != "" || tbxCity.Text != "" || tbxState.Text != "" || tbxZipCode.Text != "" || tbxPhone.Text != "" || tbxEmail.Text != "")
            {
                try
                {
                    SqlConnection con = new SqlConnection(conString);
                    SqlCommand cmd = new SqlCommand("p_UpdateCustomer_u", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Name ", SqlDbType.VarChar).Value = tbxName.Text;
                    cmd.Parameters.Add("@Address ", SqlDbType.VarChar).Value = tbxAddress.Text;
                    cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = tbxCity.Text;
                    cmd.Parameters.Add("@State", SqlDbType.VarChar).Value = tbxState.Text;
                    cmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = tbxZipCode.Text;
                    cmd.Parameters.Add("@Phone", SqlDbType.varchar).Value = tbxPhone.Text;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = tbxEmail.Text;
                    //cmd.Parameters.Add("@Email",tbxEmail.Text);


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("SQL Error" + ex.Message.ToString());

                }
            }
            else
            {
                MessageBox.Show("Please Fill every Field", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}