﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsPro
{
    public partial class frmCustomerInput : Form
    {
        private const string ConnectionString = "Data Source=DESKTOP-70QDRLQ\SQLEXPRESS;Initial Catalog=TechSupport;Integrated Security=True";
        private string p_InsertCustomer_i;
        private SqlConnection techSupportConnection;

        public string P_InsertCustomer_i { get => p_InsertCustomer_i; set => p_InsertCustomer_i = value; }

        public frmCustomerInput()
        {
            InitializeComponent();
        }

        private void frmCustomerInput_Load(object sender, EventArgs e)
        {
           
        }
        private void btnLoadRecord_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtbxName.Text))
            {
                techSupportConnection = new SqlConnection(ConnectionString);


                SqlCommand cmd = new SqlCommand(P_InsertCustomer_i, techSupportConnection);
                techSupportConnection.Open();
                cmd.Parameters.Add(new SqlParameter("@Name", txtbxName.Text));
                cmd.Parameters.Add(new SqlParameter("@Address", txtbxAddress.Text));
                cmd.Parameters.Add(new SqlParameter("@City", txtbxCity.Text));
                cmd.Parameters.Add(new SqlParameter("@State", txtbxState.Text));
                cmd.Parameters.Add(new SqlParameter("@ZipCode", txtbxZipCode.Text));
                cmd.Parameters.Add(new SqlParameter("@Phone", txtbxPhone.Text));
                cmd.Parameters.Add(new SqlParameter("@Email", txtbxEmail.Text));

                cmd.ExecuteNonQuery();
            }
        }
    }

        
    
}
