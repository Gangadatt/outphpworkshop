<?php

echo"This is third page";

?>